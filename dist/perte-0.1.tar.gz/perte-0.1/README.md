# Welcome to perte
A fast way to build lots of loss functions (```fonction de perte``` in French) in Deep Learning.

## Features

- Currently support the contrastive losses such that Triplet loss

## Installation

To install with pip, use: `pip install perte`. If you install with pip,
you should install PyTorch first by following the PyTorch [installation
instructions](https://pytorch.org/get-started/locally/).